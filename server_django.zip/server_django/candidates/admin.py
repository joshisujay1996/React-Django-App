from django.contrib import admin
from .models import Candidate
#  Register the model here to make changes or view as admin
admin.site.register(Candidate)