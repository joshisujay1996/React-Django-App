from django.contrib import admin
from .models import Job
# Register your models here.

#  Register the model here to make changes or view as admin
admin.site.register(Job)